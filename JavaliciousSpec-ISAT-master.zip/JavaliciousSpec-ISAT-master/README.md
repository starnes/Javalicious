# JavaliciousSpec-ISAT
Tests which accommodate the Astrological Sign Program
